#include <string>
using std::string;

struct R
{
  string type;
  short funct;
  short op{};
};

struct I
{
  string type;
  short op;
};

struct J {
  string type;
  short op;
};

struct Label {
  string label;
  short line;
};






    